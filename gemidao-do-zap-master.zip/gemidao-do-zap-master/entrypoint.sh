#!/bin/bash
printenv
gemidao-do-zap --de=$DE --para=$PARA --token=$TOKEN
